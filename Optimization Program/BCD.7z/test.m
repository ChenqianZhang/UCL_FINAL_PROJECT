clear;
%save('myWorkspace_3.mat');
load('myWorkspace_3.mat');

M = 10;

H_AP_new = Generation_of_RIS_to_AP_channel(y_AP,H,HR,xR,L0,d0,alpha_AP,Ky,Kz,M); %MxK
H_AP_new(1:8,:) = H_AP;
H_AP = H_AP_new;


h_d_new = zeros(M,N);
for loop = 1 : N
    xn = x_UEs(loop);
    yn = y_UEs(loop);
    h_d_new(:,loop) = Generation_of_direct_channel_LOS(xn,yn,y_AP,H,L0,d0,alpha_d,M);
end
h_d_new(1:8,:) = h_d;
h_d = h_d_new;

W0_new = zeros(M,N);
for column = 1 : N
    for row = 1 : M
    w_real = rand(1)+rand(1);
    w_img = rand(1)+rand(1);
    W0_new(row,column) = w_real + w_img*1i;
    end
end
W0_new(1:8,:) = W0;
W0 = W0_new;
