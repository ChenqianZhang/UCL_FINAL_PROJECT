function F2_n = Get_F2(noise,EN,T,K,N,a0,W0,H_AP,h_r,h_d,sigh,n)
        
                left = 0;
                % calculate F2_n
                for j = 1:N
                    if j==n
                        continue;
                    end
                    pj = (a0(j,1)*EN)/T;
                    h_RIS = W0(:,n)'*H_AP*diag(h_r(:,j));
                    h_dni = W0(:,n)'*h_d(:,j);

                    Q = zeros(K+1);     
                    Q(1:K, 1:K) = h_RIS'*h_RIS;
                    Q(1:K, K+1) = h_RIS'*h_dni;
                    Q(K+1, 1:K) = h_dni'*h_RIS;
                    Q(K+1, K+1) = 0;
                    %
                    left = left + pj*(trace(Q*sigh)+abs(h_dni)^2);
                end
                F2_n = log(left + (noise)*norm(W0(:,n)')^2)/log(2);
       
end


