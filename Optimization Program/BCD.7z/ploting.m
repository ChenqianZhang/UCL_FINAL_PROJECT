
% TCTB versus Energy Budget E, with M = 8 , N = 8
E = [4,6,8,10,12,14,16,18];
TCTB = [1.3598,1.4303,1.4839,1.5274,1.5615,1.5907,1.6153,1.6368];
TCTB = TCTB * 10^9;

plot(E,TCTB,'b-p','LineWidth', 1);
xlabel('E(Joule)'); 
ylabel('Total Computation Task-Input Bits(TCTB) of UEs');  
ylim([1*10^9, 1.75*10^9]); 
legend('BCD Optimized Solution-LOS', 'Location', 'southeast'); 
grid on;